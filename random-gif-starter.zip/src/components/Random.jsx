export default function Random() {
  return <div>Random</div>;
}
