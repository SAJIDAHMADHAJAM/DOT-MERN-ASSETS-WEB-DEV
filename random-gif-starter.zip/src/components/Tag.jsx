export default function Tag() {
  return <div>Tag</div>;
}
