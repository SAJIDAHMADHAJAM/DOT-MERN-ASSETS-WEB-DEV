const CartItem = () => {
  return <div>CartItem</div>;
};

export default CartItem;
