const Home = () => {
  const API_URL = "https://fakestoreapi.com/products";

  return <div>Home</div>;
};

export default Home;
